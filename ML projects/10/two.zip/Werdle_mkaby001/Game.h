#pragma once
class Game
{
public:
	String myString;
};

